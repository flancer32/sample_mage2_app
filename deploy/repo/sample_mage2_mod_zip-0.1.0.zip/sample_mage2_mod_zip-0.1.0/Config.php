<?php
/**
 * Hardcoded configuration for the module.
 *
 * User: Alex Gusev <alex@flancer64.com>
 */

namespace Flancer32\SampleZip;

class Config
{

    /**
     * This module's name.
     */
    const MODULE = 'Flancer32_SampleZip';
}