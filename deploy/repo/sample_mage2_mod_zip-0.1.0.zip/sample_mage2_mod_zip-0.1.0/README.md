# sample_mage2_mod_zip

Simple Magento 2 module to be deployed as ZIP.

This module is used in https://github.com/flancer32/sample_mage2_app